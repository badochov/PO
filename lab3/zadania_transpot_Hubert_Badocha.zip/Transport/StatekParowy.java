package Transport;

public class StatekParowy extends Morskie {

    public StatekParowy(){
        super();
        this.nazwa = "Statek parowy";
        this.spalanie = 1;
        this.jednostka_spalania = "t węgla/milę";
    }
}
