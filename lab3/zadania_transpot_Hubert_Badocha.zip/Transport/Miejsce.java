package Transport;


public class Miejsce {
    // Attributes
    public float wspolrzedna_x;
    public float wspolrzedna_y;
}
