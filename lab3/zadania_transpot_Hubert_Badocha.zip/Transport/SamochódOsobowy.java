package Transport;

public class SamochódOsobowy extends Lądowe {
    public SamochódOsobowy(){
        super();
        this.nazwa="Samochód osobowy";
        this.spalanie = 9;
    }
}
