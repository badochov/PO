package Transport;

public class SamolotOdrzutowy extends Powietrzne {

    public SamolotOdrzutowy(){
        super();
        this.nazwa="Samolot odrzutowy";
        this.spalanie = 88;
    }
}
